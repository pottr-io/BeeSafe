=== BeeSafe by pottr.io ===
Contributors: (this should be a list of wordpress.org userid's)
Tags: security, login, block, ip, cve
Requires at least: 5.2
Tested up to: 5.8
Requires PHP: 7.2
Stable tag: 1.0
License: GPL2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

BeeSafe is a robust WordPress plugin designed to enhance your website's security by tracking failed login attempts, blocking specific IP addresses via .htaccess, and setting lockout durations.

== Description ==

BeeSafe is a robust WordPress plugin designed to enhance your website's security by tracking failed login attempts, blocking specific IP addresses via .htaccess, and setting lockout durations. Additionally, it integrates with an external API to report failed login attempts and displays the latest WordPress CVEs, keeping your site informed about potential vulnerabilities.

== Features ==

- **Login Attempt Tracking**: Monitors and logs every failed login attempt, including username and IP address.
- **Dynamic IP Blocking**: Automatically blocks IP addresses after a configurable number of failed login attempts.
- **Lockout Durations**: Set the duration for how long an IP address should be blocked after exceeding failed login attempts.
- **External API Integration**: Sends details of failed login attempts to an external API for further analysis.
- **CVE Alerts**: Displays the latest WordPress CVEs (Common Vulnerabilities and Exposures) to keep you informed about potential vulnerabilities.

== Installation ==

1. Download the `beesafe.zip` file from the WordPress Plugin Directory or your provided URL.
2. Navigate to your WordPress dashboard, go to `Plugins` > `Add New`, and choose `Upload Plugin`.
3. Upload the `beesafe.zip` file and click `Install Now`.
4. Once installed, activate `BeeSafe by pottr.io` from your Plugins page.

== Usage ==

Once configured, BeeSafe operates automatically. You can view reports of failed login attempts and manage blocked IP addresses directly from the `BeeSafe` menu in your WordPress dashboard.

== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
Initial release.
